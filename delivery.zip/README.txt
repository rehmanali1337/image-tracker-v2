SETUP INSTRUCTIONS:

+   Install latest version of python.
+   Install required modules using "pip install -r requirements.txt" command.
+   Rename the sample-config.json file to config.json.
+   Save the config.json file.
+   Run the bot using "python main.py" command.
+   Let me know if you have some problem.